<template>

 <div>
        <h2>Grand Parent Component</h2>
    </div>

    <div>
        <father></father>
    </div>


</template>

<script>
export default {
    
}

</script>