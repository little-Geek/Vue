<template>
    <div>
        <h2>Great Grand Parent Component</h2>
    </div>

    <div>
      <grand-parent></grand-parent>
      <!-- <h3> GGP{{enteredName}}</h3> -->
      <h4> Inside Great Grand Parent Component ::{{enteredName}}</h4>
    </div>


</template>


<script>

export default {
     data(){
        return {
            enteredName:'',
            
        };
    },
   methods:{
      
   },

    mounted() { 
    this.emitter.on("changeIt", data => {
      this.enteredName = data;
      console.log(">>>"+this.enteredName);
    });
  },


}

</script>