<template>

<form @submit.prevent="submitData">

    <label>Name</label>
    <input type="text" v-model="enteredName"/>

    
        <div><button>Button</button> </div>

</form>


</template>

<script>

export default {
    emits:['add-name'],
    data(){
        return {
            enteredName:'',
            
        };
    },
    methods: {
        submitData(){
            alert('submit');
            // this.$emit('add-name' , this.enteredName);
           
            this.emitter.emit("changeIt", this.enteredName);
        }
    }
};

</script>