<template>
  <div>
    <h4>Inside Father</h4>
  </div>

  <div>
    <child @add-name="addContactDetails">  </child>
    <h3>{{childName}}</h3>
  </div>
</template>

<script>
export default {
  data() {
    return {
        childName :'',
    };
  },
  methods: {
    addContactDetails(name) {
    console.log("<<<<<<"+name);
     this.childName = name;
      
    },
  },
};
</script>