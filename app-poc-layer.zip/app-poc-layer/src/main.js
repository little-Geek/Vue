import { createApp } from 'vue'
import App from './App.vue'
import GreatGrandParent from './components/GreatGrandParent.vue'
import GrandParent from './components/GranParent.vue'
import Father from './components/Father.vue'
import Child from './components/Child'
import mitt from 'mitt';
const emitter = mitt();
const app = createApp(App);
app.config.globalProperties.emitter = emitter;
app.component('greatgrand-parent', GreatGrandParent);
app.component('grand-parent', GrandParent);
app.component('father', Father);
app.component('child', Child);
app.mount('#app');